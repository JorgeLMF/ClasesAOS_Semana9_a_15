package com.acme.learningcenter.security.domain.model.enumeration;

public enum Roles {
  ROLE_USER,
  ROLE_INSTRUCTOR,
  ROLE_ADMIN
}
