package com.acme.semana_9_a_15.shared.domain.model.mapping;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@C
public class MappingConfiguration {

    public EnhancedModelMapper modelMapper(){
        return new EnhancedModelMapper();
    }
}
