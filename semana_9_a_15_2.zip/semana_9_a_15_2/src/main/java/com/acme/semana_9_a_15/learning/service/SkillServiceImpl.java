package com.acme.semana_9_a_15.learning.service;

import com.acme.semana_9_a_15.exaption.ResourceValidationException;
import com.acme.semana_9_a_15.learning.domain.model.entity.Skill;
import com.acme.semana_9_a_15.learning.domain.persistence.SkillRepository;
import com.acme.semana_9_a_15.learning.domain.service.SkillServivce;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.validation.ConstraintViolationException;
import javax.validation.constraints;
import javax.validation.validator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class SkillServiceImpl implements SkillServivce {
   // this.

    private static final String ENTITY = "Skill";

    public SkillServiceImpl(SkillRepository skillRepository){
        this.skillRepository.findAll();
    }
    @Override
    public List<Skill> getAll() {
        return null;
    }

    @Override
    public Page<Skill> getAll(Pageable pageable) {
        return null;
    }

    @Override
    public Skill getById(Long skillId) {
        return null;
    }

    @Override
    public Skill create(Skill skill) {
        return null;
    }


    @Override
    public Skill update(Long skillId, Skill skill) {
        Set<ConstraintViolationException<Skill>> violations = validator.validate(skill);

        if(!violations.isEmpty())
            throw new ResourceValidationException(ENTITY, violations);

        Optional<Skill> skillWithName = skillRepository.findName(skill.getName());

        if(skillWithname.isPresent() && !skillWithName.get().getId().equals(id))
            throw new ResourceValidationException(ENTITY, "An the same skill with the same name already exists.");

        return skillRepository.findById(skillId).map(existingSkill -> skillRepository.save(exitingSkill.withName(skill.getname())))
                .orElseThnrow(() -> new ConfigDataResourceNotFoundException(ENTITY,skillId);
    }

    @Override
    public ResponseEntity<?> delete(Long skillId) {
        return skillRepository.findById(skillId).map(skill -> {
            skillRepository.delete(skill);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException(ENTITY,skillId));
    }
}
