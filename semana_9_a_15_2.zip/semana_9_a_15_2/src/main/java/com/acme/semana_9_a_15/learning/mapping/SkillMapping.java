package com.acme.semana_9_a_15.learning.mapping;

import com.acme.semana_9_a_15.learning.Resources.SkillResource;
import com.acme.semana_9_a_15.shared.domain.model.mapping.EnhancedModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;

import java.io.Serializable;

public class SkillMapping implements Serializable {

    @Autowired
    EnhancedModelMapper mapper;

    public SkillResource toResource(Skill model){
        return mapper.map(model, SkillResource.class);
    }

    public Page<SkillResource> modelListPage(List<Skill> modelList, Pageable pageable){
        return new PageImpl<>(mapper.mapList(modelList, SkillResource.class), pageable, modelList,size());
    }
}
