package com.acme.semana_9_a_15.learning.Resources;

import lombok.*;

@Getter
@Setter
@With
@NoArgsConstructor
@AllArgsConstructor
public class CriterionResource {

    private Long id;
    private String name;
    private SkillResource skillResource;
}
