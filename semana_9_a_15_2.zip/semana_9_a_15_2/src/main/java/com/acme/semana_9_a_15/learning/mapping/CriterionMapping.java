package com.acme.semana_9_a_15.learning.mapping;

import com.acme.semana_9_a_15.learning.Resources.CriterionResource;
import com.acme.semana_9_a_15.learning.domain.model.entity.Criterion;
import com.acme.semana_9_a_15.shared.domain.model.mapping.EnhancedModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;

import java.io.Serializable;

public class CriterionMapping implements Serializable {
    @Autowired
    EnhancedModelMapper mapper;

    public CriterionResource toResource(Criterion model){
        return mapper.map(model, CriterionResource.class);
    }

    public Page<CriterionResource> modelListPage(List<Criterion> modelList, Pageable pageable){
        return new mapper.map(resource, Criterion.class);
    }
}
