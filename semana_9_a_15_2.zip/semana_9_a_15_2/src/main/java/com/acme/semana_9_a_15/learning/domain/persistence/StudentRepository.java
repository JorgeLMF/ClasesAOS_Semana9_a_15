package com.acme.semana_9_a_15.learning.domain.persistence;

import com.acme.semana_9_a_15.learning.domain.model.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository


public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findByName(String name);
    List<Student> findAllBy(int age);




    @Override
    public Student update(Long studentId, Student request){
        return null;
    }

    //@Override
    //public Student create()
}
