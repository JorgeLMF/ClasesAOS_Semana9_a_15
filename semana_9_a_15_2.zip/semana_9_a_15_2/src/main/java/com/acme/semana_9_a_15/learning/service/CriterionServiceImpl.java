package com.acme.semana_9_a_15.learning.service;

//import
import com.acme.semana_9_a_15.exaption.ResourceValidationException;
import com.acme.semana_9_a_15.learning.domain.model.entity.Criterion;
import com.acme.semana_9_a_15.learning.domain.persistence.CriterialRepository;
import com.acme.semana_9_a_15.learning.domain.service.CriterionServivce;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;

import javax.validation.ConstraintViolationException;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public class CriterionServiceImpl {


    private static final String ENTITY = "Criterion";

    public CriterionServiceImpl(CriterionRepository CriterionRepository){
        this.CriterialRepository.findAll();
    }
    @Override
    public List<Criterion> getAll() {
        return null;
    }

    @Override
    public Page<Criterion> getAll(Pageable pageable) {
        return null;
    }

    @Override
    public Criterion getById(Long criterionId) {
        return null;
    }

    @Override
    public Criterion create(Criterion criterion) {
        return null;
    }


    @Override
    public Criterion update(Long skillId, Criterion skill) {
        Set<ConstraintViolationException<Criterion> violations = validator.validate(Criterion);

        if(!violations.isEmpty())
            throw new ResourceValidationException(ENTITY, violations);

        Optional<Criterion> CriterionWithName = CriterionRepository.findName(skill.getName());

        if(CriterionWithname.isPresent() && !CriterionlWithName.get().getId().equals(id))
            throw new ResourceValidationException(ENTITY, "An the same criterion with the same name already exists.");

        return CriterialRepository.findById(criterionId).map(existingSkill -> CriterialRepository.save(exitingCriterion.withName(skill.getname())))
                .orElseThnrow(() -> new ConfigDataResourceNotFoundException(ENTITY,criterionId);
    }

    @Override
    public ResponseEntity<?> delete(Long skillId) {
        return CriterionfindById(criterionId).map(criterion -> {
            CriterialRepository.delete(criterion);
            return ResponseEntity.ok().build();
        }).orElseThow(() -> new ResourceNotFoundException(ENTITY,criterion));
    }
}
