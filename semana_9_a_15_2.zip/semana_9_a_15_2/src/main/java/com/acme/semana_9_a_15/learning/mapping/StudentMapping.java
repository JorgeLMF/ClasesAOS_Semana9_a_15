package com.acme.semana_9_a_15.learning.mapping;

import com.acme.semana_9_a_15.learning.Resources.StudentsResources;
import com.acme.semana_9_a_15.learning.domain.model.entity.Student;
import com.acme.semana_9_a_15.learning.Resources.StudentsResources;
import com.acme.semana_9_a_15.learning.service.StudentServiceImpl;
import com.acme.semana_9_a_15.shared.mapping.EnhancedModelMapper;
import org.springframework.beans.factory.annotation.Autowired;


public class StudentMapping {

    @Autowired
    EnhancedModelMapper mapper;

    public StudentsResources toResources(Student model) {
        return mapper.map(model, StudentsResources.class);
    }
}
