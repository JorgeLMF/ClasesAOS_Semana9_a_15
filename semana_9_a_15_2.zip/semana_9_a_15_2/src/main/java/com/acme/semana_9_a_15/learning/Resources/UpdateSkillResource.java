package com.acme.semana_9_a_15.learning.Resources;

import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
public class UpdateSkillResource {
    private Long id;

    @NotNull
    @NotBlank
    @Size(max = 60)
    private String name;
}
