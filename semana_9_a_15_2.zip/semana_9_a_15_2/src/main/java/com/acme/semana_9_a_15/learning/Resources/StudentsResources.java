package com.acme.semana_9_a_15.learning.Resources;

import lombok.*;

@Getter
@Setter
@With
@NoArgsConstructor
@AllArgsConstructor

public class StudentsResources {
    private Long id;
    private String name;
    private int age;
    private String address;
}
