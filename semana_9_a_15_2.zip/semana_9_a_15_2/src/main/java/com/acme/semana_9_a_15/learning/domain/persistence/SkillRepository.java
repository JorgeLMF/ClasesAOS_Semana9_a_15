package com.acme.semana_9_a_15.learning.domain.persistence;

import com.acme.semana_9_a_15.learning.domain.model.entity.Criterion;
import com.acme.semana_9_a_15.learning.domain.model.entity.Skill;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SkillRepository extends JpaRepository<Skill, Long>{

   Optional<Skill> findName(String name);
}
