package com.acme.semana_9_a_15.learning.mapping;

import com.acme.semana_9_a_15.learning.domain.model.entity.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import



@Configuration("learningMappingConfiguration")
public class MappingConfiguration {

    @Bean
    public StudentMapping studentMapping()
}
