package com.acme.semana_9_a_15.learning.service;

import com.acme.semana_9_a_15.learning.domain.model.entity.Student;
import com.acme.semana_9_a_15.learning.domain.persistence.StudentRepository;
import com.acme.semana_9_a_15.learning.domain.service.StudentService;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service

public class StudentServiceImpl implements StudentService {

    private static final String ENTITY = "Student";

    public StudentServiceImpl(StudentRepository studentRepository){
        this.studentRepository.findAll();
    }
    @Override
    public List<Student> getAll() {
        return null;
    }

    @Override
    public Page<Student> getAll(Pageable pageable) {
        return null;
    }

    @Override
    public Student getById(Long studentId) {
        return null;
    }

    @Override
    public Student create(Student student) {
        return null;
    }

    @Override
    public Student update(Long studentId, Student request) {
        return null;
    }

    @Override
    public ResponseEntity<?> delete(Long studentId) {
        return studentRepository.findById(studentId).map(student -> {
            studentRepository.delete(student);
            return ResponseEntity.ok().build();
        }).orElseThrow(() -> new ResourceNotFoundException(ENTITY,studentId));
    }
}
