package com.acme.semana_9_a_15.shared.domain.model.mapping;

import org.modelmapper.ModelMapper;

import java.util.List;

public class EnhancedModelMapper extends ModelMapper {

    public EnhancedModelMapper(){
        super();
    }

    public <S, T> List<T> mapList(List<S> sourceList, class<T> targetClass){
        return sourceList.stream().map(item -> this.map(item, targetClass));
    }
}
