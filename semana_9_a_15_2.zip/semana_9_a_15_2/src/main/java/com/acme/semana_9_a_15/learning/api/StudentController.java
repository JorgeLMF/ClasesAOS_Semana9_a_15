package com.acme.semana_9_a_15.learning.api;

import com.acme.semana_9_a_15.learning.Resources.StudentsResources;
import com.acme.semana_9_a_15.learning.domain.service.StudentService;
import com.acme.semana_9_a_15.learning.mapping.StudentMapping;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/student")
public class StudentController {
    private final StudentService studentService;

    private final StudentMapper mapper;

    public StudentController(StudentService studentService,StudentMapper mapper){
        this.studentService = studentService;
        this.mapper = mapper;
    }

    @GetMapping("{studentId}"){
        public Page<StudentsResources> getAllStudents(Pageable pageable){
            return mapper.modelListPage(studentService.getAll(), pageable);
        }
    }
}
