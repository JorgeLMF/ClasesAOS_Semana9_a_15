package com.acme.semana_9_a_15.entity;

import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Size
@With
@Entity
@Table(name = "skills")
public class Skill {

    @Id
}
