package com.acme.semana_9_a_15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Semana9A15ApplicationTests {

    @Test
    void contextLoads() {
    }

}
