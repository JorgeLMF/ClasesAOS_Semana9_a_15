package test.cucumber;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


public class CucumberIntegrationTest {
}
