package com.acme.learningcenter.security.resource;

import lombok.*;

import javax.persistence.Entity;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@With
public class AuthenticaticateResource {
  private Long id;
  private String username;
  private String email;
  private List<String> roles;
  private List<String> token;
}
