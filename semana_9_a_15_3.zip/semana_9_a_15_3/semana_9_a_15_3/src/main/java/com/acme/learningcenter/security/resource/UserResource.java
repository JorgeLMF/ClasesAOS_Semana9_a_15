package com.acme.learningcenter.security.resource;

import lombok.*;

import java.util.List;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@With
public class UserResource {
  private Long id;
  private String username;
  private List<String> roles;
  private List<String> token;
}
