package com.acme.learningcenter.security.domain.service;

public interface UserService {
}
