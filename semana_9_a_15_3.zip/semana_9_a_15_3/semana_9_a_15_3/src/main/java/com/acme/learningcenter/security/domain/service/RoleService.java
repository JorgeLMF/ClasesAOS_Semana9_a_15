package com.acme.learningcenter.security.domain.service;

public interface RoleService {
  void seed();
}
