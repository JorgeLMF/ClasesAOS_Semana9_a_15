package com.acme.learningcenter.security.resource;

import lombok.*;


@Getter
@Setter
@AllArgsConstructor
@With
public class RoleResource {
  private Long id;
  private String name;
}
