package com.acme.learningcenter.security.domain.model.enumeration;

public class Roles {
  ROLE_USER
  ROLE_INSTRUCTOR
}
